# Pumpkin Hunt — Halloween Mini-Game (Ready-to-run ZIP)

## What is included
- `contracts/` - Solidity smart contract `PumpkinLeaderboard.sol`
- `hardhat/` - Hardhat config & deploy script
- `frontend/` - React + Vite frontend (connect wallet, simple canvas mini-game, leaderboard)
- `.env.example` - example env for deploy
- `README.md` - this file

## Quick start

### 1) Deploy contract (Hardhat)
```bash
# from repo root
cd hardhat
npm init -y
npm install --save-dev hardhat @nomiclabs/hardhat-ethers ethers dotenv
npx hardhat compile

# create .env with SOMNIA_TESTNET_RPC and DEPLOYER_PRIVATE_KEY
# then deploy to somnia:
npx hardhat run scripts/deploy.js --network somnia
```
Save the deployed contract address (copy it).

### 2) Run frontend
```bash
cd ../frontend
npm install
npm run dev
```
Open the dev URL (usually http://localhost:5173). Paste the deployed contract address into the input box in the page. Connect wallet, start playing, collect pumpkins and click "Submit Score" to write to the leaderboard.

## Notes
- The project is intentionally minimal so it's quick to run and submit to the event.
- The frontend expects you to paste the contract address into the input field (we left it empty per your request).
- If you want, I can also fill the contract address & ABI automatically into the frontend and re-generate the zip.
