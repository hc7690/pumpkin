const hre = require("hardhat");

async function main() {
  const Pumpkin = await hre.ethers.getContractFactory("PumpkinLeaderboard");
  const pumpkin = await Pumpkin.deploy();
  await pumpkin.deployed();
  console.log("PumpkinLeaderboard deployed to:", pumpkin.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
