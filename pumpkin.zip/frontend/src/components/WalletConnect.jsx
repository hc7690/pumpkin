import React from 'react'
import { ethers } from 'ethers'

export default function WalletConnect({ onConnect }){
  async function connect(){
    if(!window.ethereum) return alert('Install MetaMask')
    const provider = new ethers.BrowserProvider(window.ethereum)
    await provider.send('eth_requestAccounts', [])
    const signer = await provider.getSigner()
    const addr = await signer.getAddress()
    onConnect(addr)
  }

  return (<div>
    <button onClick={connect}>Connect Wallet</button>
  </div>)
}
