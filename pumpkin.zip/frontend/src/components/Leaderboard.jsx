import React, { useEffect, useState } from 'react'
import { ethers } from 'ethers'

export default function Leaderboard({ contractAddress }){
  const [list, setList] = useState([])

  useEffect(()=>{
    if(!contractAddress) return
    async function fetchBoard(){
      const provider = new ethers.BrowserProvider(window.ethereum)
      const abi = [
        "function getLeaderboard() view returns (tuple(string name,uint256 score)[])",
        "function getPlayers() view returns (address[])",
        "function players(address) view returns (string name, uint256 score)"
      ]
      const contract = new ethers.Contract(contractAddress, abi, provider)
      try{
        const lb = await contract.getLeaderboard()
        setList(lb)
      }catch(e){
        console.error(e)
      }
    }
    fetchBoard()
  },[contractAddress])

  return (<div>
    <h3>Leaderboard</h3>
    <ol>
      {list.map((p, i)=> (
        <li key={i}>{p.name} — {p.score.toString()}</li>
      ))}
    </ol>
  </div>)
}
