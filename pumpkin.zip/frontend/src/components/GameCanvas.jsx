import React, { useEffect, useRef, useState } from 'react'
import { ethers } from 'ethers'

// Very small playable demo: move square, collect 3 pumpkins, submit score
export default function GameCanvas({ address, contractAddress }){
  const canvasRef = useRef(null)
  const [score, setScore] = useState(0)
  const player = useRef({x:20,y:20,size:16})
  const pumpkins = useRef([
    {x:120,y:60,got:false},
    {x:220,y:160,got:false},
    {x:320,y:80,got:false}
  ])

  useEffect(()=>{
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    canvas.width = 480
    canvas.height = 320

    function draw(){
      ctx.clearRect(0,0,canvas.width,canvas.height)
      // player
      ctx.fillStyle = '#3b82f6'
      ctx.fillRect(player.current.x, player.current.y, player.current.size, player.current.size)
      // pumpkins
      pumpkins.current.forEach(p=>{
        if(!p.got){
          ctx.fillStyle = '#f97316'
          ctx.fillRect(p.x,p.y,16,16)
        }
      })
      ctx.fillStyle = '#000'
      ctx.fillText('Score: '+score, 10, 12)
    }

    let raf = null
    function loop(){ draw(); raf = requestAnimationFrame(loop) }
    loop()
    return ()=> cancelAnimationFrame(raf)
  },[score])

  useEffect(()=>{
    function onKey(e){
      const s = 6
      if(e.key === 'ArrowUp') player.current.y -= s
      if(e.key === 'ArrowDown') player.current.y += s
      if(e.key === 'ArrowLeft') player.current.x -= s
      if(e.key === 'ArrowRight') player.current.x += s

      // collision
      pumpkins.current.forEach(p=>{
        if(!p.got){
          const dx = Math.abs((p.x+8) - (player.current.x+8))
          const dy = Math.abs((p.y+8) - (player.current.y+8))
          if(dx < 16 && dy < 16){
            p.got = true
            setScore(s=>s+100)
          }
        }
      })
    }
    window.addEventListener('keydown', onKey)
    return ()=> window.removeEventListener('keydown', onKey)
  },[])

  async function submit(){
    if(!address) return alert('Connect wallet first')
    if(!contractAddress) return alert('Paste contract address first')
    try{
      const provider = new ethers.BrowserProvider(window.ethereum)
      await provider.send('eth_requestAccounts', [])
      const signer = await provider.getSigner()
      const abi = ["function submitScore(string,uint256) external"]
      const contract = new ethers.Contract(contractAddress, abi, signer)
      const tx = await contract.submitScore('Player', score)
      await tx.wait()
      alert('Score submitted!')
    }catch(e){
      console.error(e)
      alert('Submit failed: '+(e.message || e))
    }
  }

  return (<div>
    <canvas ref={canvasRef} style={{border:'1px solid #ddd'}} />
    <div style={{marginTop:8}}>
      <button onClick={submit}>Submit Score ({score})</button>
    </div>
    <div style={{marginTop:8,fontSize:12}}>Use arrow keys to move. Collect pumpkins (orange squares).</div>
  </div>)
}
