import React, { useState } from 'react'
import WalletConnect from './components/WalletConnect'
import GameCanvas from './components/GameCanvas'
import Leaderboard from './components/Leaderboard'

export default function App(){
  const [address, setAddress] = useState(null)
  const [contractAddress, setContractAddress] = useState("")

  return (
    <div style={{padding:20,fontFamily:'Arial, sans-serif'}}>
      <h1>🎃 Pumpkin Hunt</h1>
      <WalletConnect onConnect={(addr)=>setAddress(addr)} />

      <div style={{marginTop:20}}>
        <label>Contract address (paste deployed address): </label>
        <input value={contractAddress} onChange={e=>setContractAddress(e.target.value)} style={{width:'100%'}} />
      </div>

      <div style={{display:'flex',gap:20,marginTop:20}}>
        <div style={{flex:1}}>
          <GameCanvas address={address} contractAddress={contractAddress} />
        </div>
        <div style={{width:360}}>
          <Leaderboard contractAddress={contractAddress} />
        </div>
      </div>
    </div>
  )
}
